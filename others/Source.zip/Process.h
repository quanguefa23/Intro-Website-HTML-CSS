#pragma once
#include "Libs.h"

void PlayerWithPlayer();
void PlayerWithCom();
bool PlayerGoFirst(int PlayerPlayer[MaxN][MaxN], int &x, int &y);
bool PlayerGoSecond(int PlayerPlayer[MaxN][MaxN], int &x, int &y);