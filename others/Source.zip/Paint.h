#pragma once;
#include "Libs.h"

void option_console();
void Luachon(int k);
void Vebanco(int N, int M);
void DrawCaRo(int offsetX, int offsetY);
bool Move(int PlayerCom[MaxN][MaxN], int &x, int &y, int color);
void XuatKQ(int Res);
void XuatKQ_com(int Res);
void flashstring(string str, int x, int y);
void print_info();